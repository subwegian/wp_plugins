<?php
// exit if accessed directly
if( ! defined( 'ABSPATH' ) ) exit;


add_action( 'admin_enqueue_scripts', 'GENERIC_admin_enqueue_uploader_styles' );
function GENERIC_admin_enqueue_uploader_styles( $hook ) {

    $pages_arr = array(
        'post.php',
        'post-new.php',
        'profile.php',
        'user-edit.php',
    );
    
    if( in_array($hook, $pages_arr ) ){
        wp_enqueue_script( 'GENERIC-wp-media-upload', GENERIC_url() . 'js/wp_media_upload.js', array('jquery'), null, true );
    }

}


function GENERIC_display_field_media_uploader( $value, $field_array, $is_user = false ) {
    
    $description = $field_array['description'] ? '<div class="description">{description}</div>' : '';
    $img = wp_get_attachment_image_src( $value, 'medium' )[0];

    if( $img ) {
        $buttons = <<<EOD
            <a href='#' class='GENERIC-upload-image'><img src='{$img}' style='display:block;max-width:100%' /></a>
            <a href='#' class='GENERIC-remove-image button' style='display:inline-block;margin-top:10px;'>Remove Image</a>
EOD;
    } else {
        $buttons = <<<EOD
            <a href='#' class='GENERIC-upload-image button'>Upload Image</a>
            <a href='#' class='GENERIC-remove-image button' style='display:none;margin-top:10px;'>Remove Image</a>
EOD;
    }

    $media_uploader_field = <<<EOD
        <div id="{field_id}" class="GENERIC-image-upload-field">
            <h4 style="margin-bottom:.5em;">{field_name}</h4>
            {$description}
            <input type="hidden" name="{field_id}" value="{$value}" />
            {$buttons}
        </div>
EOD;

    $user_media_uploader_field = <<<EOD
        <tr class="GENERIC-custom-field">
            <th><label for="{field_id}">{field_name}</label></th>
            <td>
                <div class="GENERIC-image-upload-field">
                    <input type="hidden" name="{field_id}" value="{$value}" />
                    {$buttons}
                    {$description}
                </div>
            </td>
        </tr>
EOD;


    if( $is_user ) return $user_media_uploader_field;
    return $media_uploader_field;
}



