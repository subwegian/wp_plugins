jQuery( document ).ready(function($) {
    console.log( "ready!" );
    /*
     * Select/Upload image(s) event
     */
    $('body').on('click', '.GENERIC-upload-image', function(e){

        e.preventDefault();

        var button = $(this);
        var custom_uploader = wp.media({
            title: 'Insert image',
            library : {
                // uncomment the next line if you want to attach image to the current post
                // uploadedTo : wp.media.view.settings.post.id, 
                type : 'image'
            },
            button: {
                text: 'Use this image' // button label text
            },
            multiple: false // for multiple image selection set to true
        });
        
        custom_uploader.on('select', function() { // it also has "open" and "close" events 
            var attachment = custom_uploader.state().get('selection').first().toJSON();

            $(button)
                .removeClass('button')
                .html('<img class="true_pre_image" src="' + attachment.sizes.medium.url + '" style="max-width:95%;display:block;" />')
                .parent()
                .find('input[type="hidden"]')
                .val(attachment.id)
                .parent()
                .find('.GENERIC-remove-image')
                .show();
            
            /* if you set multiple to true, here is some code for getting the image IDs
            var attachments = frame.state().get('selection'),
                attachment_ids = new Array(),
                i = 0;
            attachments.each(function(attachment) {
                attachment_ids[i] = attachment['id'];
                console.log( attachment );
                i++;
            });
            */
            
        });

        custom_uploader.open();
        
    });

    $('body').on('click', '.GENERIC-remove-image', function(){
        $(this)
            .hide()
            .parent()
            .find('.GENERIC-upload-image')
            .addClass('button')
            .html('Upload image')
            .parent()
            .find('input[type="hidden"]')
            .val('');
        return false;
    });
});
